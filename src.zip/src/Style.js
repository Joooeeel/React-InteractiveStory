import styled, { createGlobalStyle } from 'styled-components';
import font from './resource/historyFont.otf';

export const GlobalStyle = createGlobalStyle`
	body {
		margin: 0px;
		background-color:black;
	}
`;